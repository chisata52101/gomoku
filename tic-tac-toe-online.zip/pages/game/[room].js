import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import io from "socket.io-client";

let socket;

export default function Game() {
  const router = useRouter();
  const { room } = router.query;
  const [board, setBoard] = useState(Array(9).fill(null));
  const [turn, setTurn] = useState("X");
  const [message, setMessage] = useState("");
  const [myTurn, setMyTurn] = useState(false);

  useEffect(() => {
    if (!room) return;

    if (!socket) {
      socket = io();
    }

    socket.emit("joinRoom", room);

    socket.on("message", (msg) => {
      setMessage(msg);
    });

    socket.on("move", (moveIndex) => {
      setBoard((prev) => {
        const newBoard = [...prev];
        newBoard[moveIndex] = turn === "X" ? "O" : "X";
        return newBoard;
      });
      setMyTurn(true);
    });

    setMyTurn(true);

    return () => {
      if (socket) {
        socket.off("message");
        socket.off("move");
      }
    };
  }, [room]);

  const handleClick = (index) => {
    if (board[index] || !myTurn) return;

    const newBoard = [...board];
    newBoard[index] = turn;
    setBoard(newBoard);
    setMyTurn(false);

    socket.emit("move", { room, move: index });
  };

  return (
    <div style={{ textAlign: "center", marginTop: 30 }}>
      <h2>房間：{room}</h2>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 60px)",
          gap: "5px",
          justifyContent: "center",
        }}
      >
        {board.map((cell, i) => (
          <button
            key={i}
            onClick={() => handleClick(i)}
            style={{ width: 60, height: 60, fontSize: 24 }}
          >
            {cell}
          </button>
        ))}
      </div>
      <p>{myTurn ? "你的回合" : "等待對手..."}</p>
      <p>{message}</p>
    </div>
  );
}

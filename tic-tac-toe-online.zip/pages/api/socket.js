import { Server } from "socket.io";

const ioHandler = (req, res) => {
  if (!res.socket.server.io) {
    console.log("Setting up socket.io");

    const io = new Server(res.socket.server);
    res.socket.server.io = io;

    io.on("connection", (socket) => {
      console.log("New client connected", socket.id);

      socket.on("joinRoom", (room) => {
        socket.join(room);
        console.log(`${socket.id} joined room ${room}`);
        socket.to(room).emit("message", `User ${socket.id} joined the room`);
      });

      socket.on("move", ({ room, move }) => {
        socket.to(room).emit("move", move);
      });

      socket.on("disconnect", () => {
        console.log("Client disconnected", socket.id);
      });
    });
  }
  res.end();
};

export default ioHandler;
